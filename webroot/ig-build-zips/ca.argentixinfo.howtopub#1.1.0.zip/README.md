# How to Publish a FHIR Implementation Guide

This FHIR Implementation Guide provides guidance on using HL7 IG Publisher's `-go-publish` option to publish an IG to a website.
